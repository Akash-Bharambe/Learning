#include<stdio.h>
#include<stdlib.h>

//function who is having return type as structure 

struct Date
{
    int dd;
    int mm;
    int yy;
};

struct Date accept();

int main(void)
{

    struct Date d1,d2;
    d1=accept();
    d2=accept();
    printf("DATE d1 : %d %d %d",d1.dd,d1.mm,d1.yy);
    printf("\n DATE d2 : %d %d %d",d2.dd,d2.mm,d2.yy);
    return 0;
}

struct Date accept()
{
    struct Date d;
    printf("Enter Date :");
    scanf("%d",&d.dd);
    printf("Enter Month :");
    scanf("%d",&d.mm);
    printf("Enter Year :");
    scanf("%d",&d.yy);
    return d;
    
}