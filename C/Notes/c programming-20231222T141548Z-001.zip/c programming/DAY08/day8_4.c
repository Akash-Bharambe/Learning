#include<stdio.h>
#include<stdlib.h>

union student
{
    int id;
    int marks;
};
int main(void)
{
    union student st;
    st.id=1;
    // 0000 0000 0000 0000 0000 0000 0000 0001 
    st.marks=10;
    // 0000 0000 0000 0000 0000 0000 0000 1010 
    printf("ID : %d",st.id);
    printf("\n Marks %d",st.marks);
    printf("\n size : %d",sizeof(st));
    return 0;
}



/*
union student
{
    int id;
    int marks;
};
int main(void)
{
    union student st;
    st.id=1;
    printf("ID : %d",st.id);
    st.marks=10;
    printf("\n Marks %d",st.marks);
    printf("\n size : %d",sizeof(st));
    return 0;
}

*/

/*
//bit field

struct student
{
    char name[20];
    int rollno:5;
    int marks:4;
};
int main(void)
{
    struct student s; // s is a variable of type struture
    printf("size : %d",sizeof(s));

}

*/