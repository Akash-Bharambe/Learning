#include<stdio.h>
#include<stdlib.h>


struct Employee
{
    int id;
    int salary;
};

int main(void)
{
    struct Employee e; //e is a variable
    struct Employee *ptr=&e; // pointer variable of type structure
    e.id=1;
    e.salary=70000;
    printf("ID : %d Salary : %d",e.id,e.salary);
    printf("\n ID : %d SALARY : %d",ptr->id,ptr->salary);
    return 0;
}

/*
#pragma pack(1) //intimation to compiler please pack the memory 1byte every time
struct student
{
    int rollno;
    int id;
    char grade;
};
int main(void)
{
    struct student s;
    printf("size : %d",sizeof(s));
    return 0;
}
*/


/*
struct Employee
{
    double d; // 8 bytes 
    int sal; //8bytes ( 4 wil be used for sal and 4 slack bytes)
    int grade;
    char ch;
};
int main(void)
{
    struct Employee e;
    printf("size : %d",sizeof(e));
    return 0;
}
*/

/*
struct Student
{
    int id;
    int marks;
    int result;
    char grade;
    char ch;
    int num1;
    char ch2;
};
int main(void)
{
    struct Student s;
    printf("size : %d",sizeof(s));
    return 0;
}

*/