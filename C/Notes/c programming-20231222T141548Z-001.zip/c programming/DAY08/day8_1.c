#include<stdio.h>
#include<stdlib.h>


//nested structure 
struct Student
{
    int rollno;
    int marks;
    struct //anonymous structure
    {
        int dd;
        int mm;
        int yy;
    }d;
};
int main(void)
{
    struct Student s;
    s.rollno=1;
    s.marks=90;
    s.d.dd=22;
    s.d.mm=12;
    s.d.yy=20;
    printf("Roll no : %d Marks : %d",s.rollno,s.marks);
    printf("\n %d :  %d : %d",s.d.dd,s.d.mm,s.d.yy);
    return 0;
}



/*
struct  // anonymous structure 
{
    int num1;
    int num2;
}var;


int main(void)
{    
    var.num1=30,var.num2=20;
    printf("%d %d",var.num1,var.num2);
    return 0;
}

*/







/*
typedef struct Employee
{
    int id;
    int salary;
}EMP;

int main(void)
{
    struct Employee e; //e is variable created using real name
    EMP e2; //e2 is a variable created using alias name / nick name

    return 0;
}
*/


/*
//array of structure

struct Employee
{
    int id;
    float salary;
    char name[20];
};

int main(void)
{
    struct Employee emp[3]; //array of structure
    int i;
    for(i=0;i<3;i++)
    {
        printf("Enter ID :");
        scanf("%d",&emp[i].id);
        printf("Enter salary :");
        scanf("%f",&emp[i].salary);
        printf("Enter Name :");
        scanf("%s",emp[i].name);
    }

    for(i=0;i<3;i++)
    {
        printf("\n ID %d Salary : %f Name : %s",emp[i].id,emp[i].salary,emp[i].name);
        printf("\n &ID %u &Salary : %u Name : %u",&emp[i].id,&emp[i].salary,emp[i].name);
    }
    return 0;
}

*/

/*
struct Employee
{
    int id;
    int salary;
};

int main(void)
{
    struct Employee e; //e is a structure variable
    printf("Enter  ID :");
    scanf("%d",&e.id);
    
    printf("Enter  salary :");
    scanf("%d",&e.salary);

    printf("ID : %d SALARY : %d",e.id,e.salary);
    
    return 0;
}

*/




/*
struct Student
{
    int id;
    int marks;
    float percentage;
}s1={1,86,90}; //initialization of structure variable at the time of declaration

int main(void)
{
    struct Student s2,s3;//3 structure variables
    s2.id=2;
    s2.marks=90;
    s2.percentage=90;
    printf("S1 Record : %d %d %f",s1.id,s1.marks,s1.percentage);
    printf("\n S2 Record : %d %d %f",s2.id,s2.marks,s2.percentage);
    s3=s2; //copying the data from one structure to another
    printf("\n S3 Record : %d %d %f",s3.id,s3.marks,s3.percentage);
    return 0;
}

*/

/*
struct Student
{
    int id;
    int marks;
    float percentage;
}s1; // we can create a structure variable at the time of declaraion also

int main(void)
{
 
    s1.id=1;
    s1.marks=80;
    s1.percentage=85.5;
    printf("%d %d %f",s1.id,s1.marks,s1.percentage);
    return 0;
}

*/

/*
struct Student
{
    int id;
    int marks;
    float percentage;
};

int main(void)
{
    struct Student s1;//structure variable 
    s1.id=1;
    s1.marks=80;
    s1.percentage=85.5;
    printf("%d %d %f",s1.id,s1.marks,s1.percentage);
    return 0;
}
*/