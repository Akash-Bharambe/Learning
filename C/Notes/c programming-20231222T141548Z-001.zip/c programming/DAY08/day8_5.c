#include<stdio.h>
#include<stdlib.h>


//fseek()
//ftell()


int main(void)
{
    FILE *fptr;
    char ch;
    fptr=fopen("src.txt","r"); //r : reading mode
    if(fptr==NULL)
    {
        printf("File not found");
        return 0;
    }

    //fseek(fptr,5,SEEK_SET); //SEEK_SET will move the cursor fom begining of file

    //printf("%c is at location %u",fgetc(fptr),ftell(fptr));

    //fseek(fptr,7,SEEK_CUR); //SEEK_CUR it will move from current cursor position
    //printf("\n %c is at location %u",fgetc(fptr),ftell(fptr));


    fseek(fptr,-5,SEEK_END); //SEEK_CUR it will move from current cursor position
    printf("\n %c is at location %u",fgetc(fptr),ftell(fptr));


return 0;
}

/*
//reading the contents from file

int main(void)
{
    FILE *fptr;
    char ch;
    fptr=fopen("source.txt","r"); //r : reading mode
    if(fptr==NULL)
    {
        printf("File not found");
        return 0;
    }

    while((ch=fgetc(fptr))!=EOF)
    {
        fputc(ch,stdout);
    }
    fclose(fptr);

    return 0;
}

*/