#include<stdio.h>
#include<stdlib.h>


//conditional operator / Ternary operator ( ? :) 
// (expression1) ?  TRUE : FALSE
//expression1 is true it goes to TRUE PART else it goes to FALSE part

int main(void)
{
    int num1=40,num2=20;
    int max;
    max= (num1>num2) ? num1 : num2;
    printf("MAx : %d",max);

    return 0;
}






/*

//  << LEFT SHIFT OPERATION
// x << n = x * 2^n

 // >> RIGHT SHIFT OPERATION 
// x >> n = x / 2^n

//-30 >> 3 = -30 / 2^3 = -30 / 8 = -3.75 ===> %d ===> -4 


int main(void)
{
    printf("30<<2 : %d",30<<2);
    printf("\n -20<<3 : %d",-20<<3);
    printf("\n 40>>3 : %d",40>>3);
    printf("\n -30>>3  : %d",-30>>3);
    return 0;
}
*/


/*
int main(void)
{
    int a=12;
    int b=10;

    printf("\n a&b : %d",a&b);
    //a : 12 : 1 1 0 0
    //b : 10 : 1 0 1 0
    //=====================
    //a&b:     1 0 0 0  ==> 8 


    printf("\n a|b : %d",a|b);
    //a : 12 : 1 1 0 0
    //b : 10 : 1 0 1 0
    //=====================
    //a|b:     1 1 1 0  ==> 14

    printf("\n a^b : %d",a^b); //XOR indicates if both bits are different then return 1
    //a : 12 : 1 1 0 0
    //b : 10 : 1 0 1 0
    //=====================
    //a^b:     0 1 1 0  ==> 6

    printf("\n ~a : %d",~a);
    //a = 12 
    //~n = -(n+1) = ~12 = -(12+1) = -13  

    return 0;
}

*/