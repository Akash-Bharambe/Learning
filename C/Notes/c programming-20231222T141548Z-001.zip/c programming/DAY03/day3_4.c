#include<stdio.h>
#include<stdlib.h>

//A-Z : 65 to 90
//a-z : 97 to 122
//0-9 : 48 to 57

int main(void)
{
    char ch;
    printf("Enter Character:");
    scanf("%c",&ch);
    if(ch>=65 && ch<=90)
        printf("UPPER CASE LETTER ");
        else
            if(ch>=97 && ch<=122)
                printf("LOWER CASE LETTER");
                else
                 if(ch>=48 && ch<=57)
                    printf("IT IS A DIGIT");
                        else
                            printf("SPECIAL CHARACTER");
                        return 0;
}


/*
int main(void)
{

    int num;
    printf("Enter Num :");
    scanf("%d",&num);
    if(num%2==0)  // Num 20 ==> if(20%2==0) if(0 == 0 ) if(true)
        printf("EVEN NUMBER");
    else
        printf("ODD NUMBER ");

    return 0;
}

*/