#include<stdio.h>
#include<stdlib.h>

// ++ / -- Increment operation / decrement operation
// They both will incr/decr value by 1

// variable++  // It is called as post increment operation
//variable--  //  // It is called as post decrement  operation

// ++ variablename // It is called as pre increment operation
//--variable  //  // It is called as pre decrement  operation

int main(void)
{
    int a=2,b;
    b=a++ + a-- + ++a + --a;
    printf("A : %d B : %d",a,b);
    return 0;
}


//mulitple occuranc of pre / post operation inside printf() 
// traverse from right to left

/*
int main(void)
{
    int i=4;
    printf("%d %d %d",++i,i,i++);
    return 0;
}
*/




/*

int main(void)
{
    int num=30;
    int result;
    printf("Num : %d",num);
    result=++num; //pre 
    // WHEN WE PERFORM PRE OPERATION AT THAT TIME 
    //FIRST OPERATION IS PERFORMED
    //then VALUE IS ASSIGNED 
    
    printf("\n Num : %d Result : %d",num,result);
    return 0;
}

*/



/*
int main(void)
{
    int num=30;
    int result;
    printf("Num : %d",num);
    result=num++; //post 
    // WHEN WE PERFORM POST OPERATION AT THAT TIME 
    //FIRST VALUE IS ASSIGNED 
    //THEN OPERATION IS PERFORMED
    printf("\n Num : %d Result : %d",num,result);
    return 0;
}
*/



 



/*
// Relational operator , 1(true) or 0 (false)

int main(void)
{
    int num1;
    int num2;
    printf("Enter first number :");
    scanf("%d",&num1);
    
    printf("Enter second number :");
    scanf("%d",&num2);

   // printf("NUM1 < NUM2 : %d",num1<num2);
  
    printf("\n NUM1 > NUM2 : %d",num1>num2);
     printf("\n NUM1 ==  NUM2 : %d",num1==num2);
     printf("\n NUM1 <=  NUM2 : %d",num1<=num2);
     printf("\n NUM1 >=  NUM2 : %d",num1>=num2);
     printf("\n NUM1 !=  NUM2 : %d",num1!=num2);


    return 0;
}

*/




/*
int main(void)
{
    int num=40;
    num+=5;  //short hand operator //num = num+5 
    printf("Num : %d",num); 
    num-=10; // num = num-10
    printf(" \n Num : %d",num); 
    return 0;
}
*/


/*
int main(void)
{
   int num1=40;
   int num2=20;

   printf("%d",num1+num2);
   printf("\n %d",num1-num2);
   printf("\n %d",num1*num2);
   printf("\n %d",num1/num2); // div gives us quotient
   printf("\n %d",num1%num2); //MOD gives us remainder 

        // 40/20  = 2 remainder : 0
        //5/3 = 1 5%3 = 2 remainder 

    return 0;
}

*/