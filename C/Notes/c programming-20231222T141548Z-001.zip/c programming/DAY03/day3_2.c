#include<stdio.h>
#include<stdlib.h>


int main(void)
{
    int a=1;
    int b=0,c=4;
    int d;
    d=a && (b++ && c++);
    printf("A : %d B: %d C: %d D: %d",a,b,c,d);
    printf("\n Logical NOT : %d",!d);
    return 0;
}

/*
int main(void)
{
    int a=10,b=3,c=0,d;
    printf("A : %d B : %d C: %d",a,b,c);
    d=a++ || (++b && c++);
    printf("\nA : %d B : %d C: %d D : %d",a,b,c,d);
    return 0;
}
*/
