#include<stdio.h>
#include<stdlib.h>

int main(void)
{
    char ch='A'; 
    printf("%c %d",ch,ch);
    return 0;
}



//escape sequence
// '\n' New line character
// '\b' back space
// '\t' Tab space
// '\r' carriage return

/*
int main(void)
{
    //\r it brings the cursor on first character of same line and starts overwriting
    printf("good Morning\rExcellent");
        //  Excellenting
    return 0;

}
*/



/*
// " CProgramming"
int main(void)
{
    printf("\"CProgramming\"");
    return 0;
}

*/

/*
int main(void)
{
    printf("good\tmorning");
    return 0;
}
*/



/*
int main(void)
{
    printf("Good Morning\bg");
    return 0;
}
*/
/*
int main(void)
{
    printf("hello");
    printf("\nOC2 Precat Batch");

    return 0;
}
*/