#include<stdio.h>
#include<stdlib.h>



/*
int main(void)
{
    int i=50;
    char ch='A'; 
    float fval=9.8;

    printf("%d  %d  %d",sizeof(int),sizeof(i),sizeof(30));
    printf("\n %d %d %d",sizeof(ch),sizeof(char),sizeof('M'));
    printf("\n %d %d %d",sizeof(fval),sizeof(float),sizeof(5.4f));
    printf("\n %d %d",sizeof(double),sizeof(7.546));
    

    // every character is given one numeric value
    //ASCII Character set
    // A-Z 65 to 90 A:65 B : 66 C : 67 D : 68......
    //a-z 97 to 122
    //0 to 9  : 48 to 57


    //M : 77
    //sizeof('M')
    //sizeof(77)
    //4 bytes

    return 0;
}


*/


/*
int main(void)
{
    int val=50; // if we assign value to the variable at the time of declaration
        // Variable Initialization
    float f=40.67;
    char ch='A';

    printf("val : %d flaot value : %f Character Value : %c",val,f,ch);

    ch='S';
    val=70;
    printf("\n val : %d  Character Value : %c",val,ch);
    return 0;
}
*/


/*

int main(void)
{

    int a; // int is a datatype , a is a variablename 
        // variable declaration
    a=30; // defining the value to variable a as 30 ( Variable definition)
    printf("Value of A variable  %d",a);
    return 0;
}
*/
