#include<stdio.h>
#include<stdlib.h>

/*
int main(void)
{
    int num1,num2;
    printf("Enter Num1 : ");
    scanf("%d",&num1);
    printf("\n Enter Num2 : ");
    scanf("%d",&num2);
    printf("\n User have entered Num1 : %d Num2 : %d",num1,num2);
    
    return 0;
}

*/


/*
int main(void)
{
    int num=350;
    int i;
    i=printf("Num=%d",num);
        //    Num=350
    printf("\n%d",i);
    return 0;
}

*/


/*
int main(void)
{
    int i;
    i=printf("Sunbeam");
    //Sunbeam ==>total 7 characters are printed by printf() 
    //that will get strored into variable i 
    printf("\n Value of i : %d",i);
    return 0;
}
*/


/*
int main(void)
{
    float fval=7.8565;
    printf("%.2f",fval);
    printf("\n %8.3f",fval);
    //8.3 means, total 8 spaces , 3 digits after decimal
    // _ _ _ 7 . 8 5 7
    // _ _ _ _ _ _ _ _
    return 0;
}
*/

/*
int main(void)
{
    int num1=10;
    int num2=20;
    printf("%d%d",num1,num2);
    printf("\n %6d %6d",num1,num2);
    // _ _ _ _ 1 0    _ _ _ _ 2 0 
    // _ _ _ _ _ _    _ _ _ _ _ _ 
    printf("\n %-6d %-6d",num1,num2);

    // 1 0 _ _ _ _    2 0 _ _ _ _ 
    return 0;
}
*/


/*

int main(void)
{
    int num=0x32; // if any number is preceded with ox it is called as hexa decimal

    printf("Num : %d Num : %o Num : %x",num,num,num);
    // 32
    // 3 * 16^1  + 2*16^0
    // 48         + 2
    //50

    // 3    2
    //0011  0010
    // 00110010
    // 00   110   010
    //       6     2

    return 0;
}

*/

/*
int main(void)
{
    int num=064; 
    //if we preced any number with o or 0 then it is treated as octal number
    printf("\n Num : %o",num); //%o stands for octal
    printf("\n num : %d",num);
    printf("\n num : %x ",num); //%x stands for hexa decimal format
    return 0;
}

*/