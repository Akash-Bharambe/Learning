#include<stdio.h>
#include<stdlib.h>


int main(void)
{
    unsigned char ch=259;  // 0 to 255
    //256 : 0
    //257 : 1
    //258 : 2
    //259 : 3
    printf("%d",ch);
    return 0;
}


/*
int main(void)
{
    char ch=129; //by default it is signed range
    printf("%d",ch);
    return 0;
}
*/