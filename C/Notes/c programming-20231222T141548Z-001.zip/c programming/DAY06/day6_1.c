#include<stdio.h>
#include<stdlib.h>

int fact_with_rec(int num);

int main(void)
{
    int num;
    int result;
    printf("Enter Number :");
    scanf("%d",&num);
    result=fact_with_rec(num);
    printf("Factorial : %d ",result);
    return 0;
}


int fact_with_rec(int num)
{
    if(num==1)
        return 1;
    else 
        return num* fact_with_rec(num-1);
}


/*
int fact_without_rec(int num);

int main(void)
{
    int num;
    int result;
    printf("Enter Number :");
    scanf("%d",&num);
    result=fact_without_rec(num);
    printf("Factorial : %d ",result);
    return 0;
}
// Loop 
int fact_without_rec(int num)
{
    int ans=1;
    while(num)
    {
        ans=ans*num;
        num--;
    }
    return ans;
}

*/
//num = 4 
//while(4) ans=ans * num   ans = 1 * 4 ans=4 num=3
//while(3) ans=ans*num ans= 4 * 3 ans=12 num=2
//while(2) ans = ans *num  ans = 12 * 2 =24 ans=24 num=1
//while(1) ans =ans*num ans= 24*1 = 24 ans = 24 num=0
//while(0) FALSE return 24 