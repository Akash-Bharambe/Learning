#include<stdio.h>
#include<stdlib.h>

int main(void)
{
    char str[10]="Sunbeam";
    //str 630 S
    //631 u //632 n  //633 b  //634  e   //635 a  //636 m 

    printf("Base Address : %u",str);
    printf("\n %s",str+2);
    //str+2
    //630+2
    //632

    printf("\n %c",*(str+2));
    //*(str+2)
    //*(630+2)
    //*(632)
    //n 


    return 0;
}


/*
int main(void)
{
    char str1[20]="Sunbeam";
    char str2[15]={'S','u','n','b','e','a','m','\0'};
    char *str3="Sunbeam";
    char str4[]="sunbeam"; // s u n b e a  m \0
    char str5[]="sunbeam\0"; // s u n b e a m \0 \0

    printf("str1 : %s",str1);
    printf("\n str2 : %s",str2);
    printf("\n str3 : %s",str3);

    printf("\n size of str1 : %d",sizeof(str1));
    printf("\n size of str2 : %d",sizeof(str2));
    printf("\n size of str3 : %d",sizeof(str3));
    printf("\n size of str4 : %d",sizeof(str4));
     printf("\n size of str5 : %d",sizeof(str5));




    return 0;
}
*/