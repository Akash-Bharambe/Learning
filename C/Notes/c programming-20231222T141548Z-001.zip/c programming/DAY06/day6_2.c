#include<stdio.h>
#include<stdlib.h>



void accept_data(int arr[3]);  // function is taking argument as an array


int main(void)
{
    int a[3];
    int b[3];
    accept_data(a);//function call
    accept_data(b); //function call
       return 0;
}



void accept_data(int arr[3])
{
    int i;
    printf("Enter  array elements :");
    for(i=0;i<3;i++)
    {
        scanf("%d",&arr[i]);
    }

    printf("\n Array elements are :");
    for(i=0;i<3;i++)
    {
        printf(" %d ",arr[i]);
    }
}



/*
int main(void)
{
    int arr[5]={10,20,30,40,50};
            //620 624  628  632  636
    printf("base address : %u",arr);
    printf("\n %d %d",arr[0],*arr);

    //*arr
    //*620
    //10

    printf("\n %d %d",arr[1],*(arr+1));
    // *(arr+1)
    //*(620 + 1)
    //*(624)
    //20
    printf("\n %d %d",arr[2],*(arr+2));
    printf("\n %d %d",arr[3],*(arr+3));
    printf("\n %d %d",arr[4],*(arr+4));
    

    printf("\n *arr+1 : %d",*arr+1);
    // *arr+1
    //*620 + 1
    //10+1
    //11

    printf("\n *(arr+2)+5 : %d",*(arr+2)+5);
    //*(arr+2)+5
    //*(620+2) +5
    //*(628) + 5
    //30 + 5 
    //35
    printf("\n *arr++ : %d",(*arr)++);


    return 0;
}


*/

/*
int main(void)
{
    int arr[4];
    int i;
    printf("Enter Array elements :");
    for(i=0;i<4;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("\n Array elements :");
    for(i=0;i<4;i++)
    {
        printf(" %d ",arr[i]);
    }
    return 0;
}
*/

/*
int main(void)
{
    int arr[]; // INVALID 
    int arr[]={1,3,5,6}; //VALID

    return 0;
}
*/

/*
int main(void)
{
    int arr[6]; //declaration part
    arr[0]=10; //define it at later stage 
    arr[1]=40;// remaining elements recieves garbage value
    int i;
    for(i=0;i<6;i++)
        printf(" \n %d %u",arr[i],&arr[i]);
    printf("\n size : %d",sizeof(arr));

    return 0;
}

*/


/*
int main(void)
{
    int arr[5]={11,33}; // partial initilization of array (remainig elements receives 0 as value)
    int i;
    for(i=0;i<5;i++)
        printf(" \n %d %u",arr[i],&arr[i]);
    printf("\n size : %d",sizeof(arr));

    return 0;
}
*/

/*
int main(void)
{
    int arr[5]={11,22,33,44,55};
    int i;
    for(i=0;i<5;i++)
        printf(" \n %d %u",arr[i],&arr[i]);
    printf("\n size : %d",sizeof(arr));

    return 0;
}
*/