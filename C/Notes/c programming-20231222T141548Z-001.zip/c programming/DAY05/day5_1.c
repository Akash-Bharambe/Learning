#include<stdio.h>
#include<stdlib.h>


//funcion declaration

void swap(int n1,int n2);

int main(void)
{
    int num1,num2;
    num1=10;
    num2=5;
    printf("\n Before SWAP : num1 : %d num2 : %d ",num1,num2);
    printf("\n calling swap function....");
    swap(num1,num2); //function call 
    printf("\n back to main function....");
    printf("\n After SWAP : num1 : %d num2 : %d ",num1,num2);
    return 0;
}

void swap(int n1,int n2)
{
    printf("\n Inside Swap Function Before %d %d",n1,n2);
    int temp;
    temp=n1;
    n1=n2;
    n2=temp;
    printf("\n Inside Swap Function After %d %d",n1,n2);
}

// n1 = 10 n2=5
// int temp;
//temp=10
//n1=5
//n2=10
//n1=5 n2=10 


/*
int accept_data();

int main(void)
{
    int num1,num2,num3;
    num1=accept_data(); //function call
    num2=accept_data();
    num3=accept_data();
    printf("%d %d %d",num1,num2,num3);
    
    return 0;
}

int accept_data() //function definition
{
    int num;
    printf("Enter Num :");
    scanf("%d",&num);
    return num;

}
*/






