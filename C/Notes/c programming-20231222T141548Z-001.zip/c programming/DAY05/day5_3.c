#include<stdio.h>
#include<stdlib.h>

void swap(int *n1,int *n2); // passing pointer variable as an argument

int main(void)
{
    int num1=30,num2=20;
    printf("Before : num1:%d num2:%d",num1,num2);
    swap(&num1,&num2); // call by address concept
    printf("\n after  : num1:%d num2:%d",num1,num2);
    return 0;
}


void swap(int *n1,int *n2)
{
    int temp;
    temp=*n1;
    *n1=*n2;
    *n2=temp;
}


/*
int main(void)
{
    void *ptr; // generic pointer  / void pointer
    //void *ptr=NULL;
    int num=20;
    char ch='A';
    ptr=&num;  // void pointer is holding addres of num
    printf("\n &num : %u ptr : %u",&num,ptr);
    printf("\n Num : %d *ptr : %d",num,*(int *)ptr);
    
    ptr=&ch; //void pointer is holding address of ch
    printf("\n &ch : %u ptr : %u",&ch,ptr);
    printf("\n ch : %c *ptr : %c",ch,*(char *)ptr);
    
    return 0;

}

*/





/*
int main(void)
{
    int num=40;
    char ch='A';
    int *ptr=&num; //ptr is holding address of num 
    char *cptr=&ch;
    printf("sizeof (ptr) : %d sizeof (cptr ) :%d ",sizeof(ptr),sizeof(cptr));
    printf("\n num : %d *ptr : %d",num,*ptr); //*ptr : value at ptr 
    printf("\n ch : %c *cptr : %c",ch,*cptr);
    return 0;

}

*/



/*
int main(void)
{
    //int num=10;
    int num = 257;
    char *ch;
    ch=&num;
    printf("Num : %d *ch : %d",num,*ch);

    return 0;
}
*/
/*
int main(void)
{
    int num=50;
    int *ptr=&num;
    int **pptr=&ptr;
    printf("%d %d",num,*ptr);
    printf("\n address: %u %u",&num,ptr);

    printf("\n pptr : %u &ptr : %u",pptr,&ptr);

    printf("\n num : %d *ptr : %d **pptr : %d",num,*ptr,**pptr);
    num=60;
    printf("\n num : %d *ptr : %d **pptr : %d",num,*ptr,**pptr);
    *ptr=70;
    printf("\n num : %d *ptr : %d **pptr : %d",num,*ptr,**pptr);
    **pptr=80;
    printf("\n num : %d *ptr : %d **pptr : %d",num,*ptr,**pptr);


    return 0;
}

*/