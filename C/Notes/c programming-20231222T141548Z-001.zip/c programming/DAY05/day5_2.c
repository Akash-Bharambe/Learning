#include<stdio.h>
#include<stdlib.h>


extern int a; //data section 
int main()
{
    printf("a : %d",a);
    return 0;
}
a=50;



/*
void test();
int main(void)
{
    test();
    test();
    return 0;
}

void test()
{
    int num=20; // local variable (auto)
    static int s=40;  //static variable  must be initialized at the time of declaration
    //data section
    printf("\n num : %d s : %d",num,s);
    num++;
    s++;
    printf("\n num : %d s : %d",num,s);
}

*/

/*
//register int b=45; // REGSITER VARIABLES CAN NOT BE CREATED IN GLOBAL AREA 

int main(void)
{
    register int a=30; // request is made to compiler that we want to store variable a inside CPU register
    printf("\n a : %d",a);
    printf("Enter register value :");
    scanf("%d",&a); //error: address of register variable 'a' requested
    return 0;
}

*/

/*
//storage classes 

int main(void)
{
    auto int num=50; //local to main()
    printf("Num:%d",num);

    return 0;
} //scope of main()

//life of num variable is only within main scope 
//num varibale can be accessed only within main

*/
