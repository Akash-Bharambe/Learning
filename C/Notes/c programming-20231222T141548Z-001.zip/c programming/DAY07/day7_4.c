#include<stdio.h>
#include<stdlib.h>

#define PI 3.14
int main(void)
{
    #ifdef PI
        printf("PI is defined");
    #else
        printf("PI is not defined");
    #endif
    return EXIT_SUCCESS;
}

/*

#define STRDISP(x) {printf("\n %s",#x+2);}
int main(void)
{
    STRDISP(sunbeam);
    //{printf("\n %s","sunbeam"+2);}
    return 0;
}

*/



/*
// # represents string 
// # ==> " "
#define STRDISP(x) {printf("\n %s",#x);}
int main(void)
{
    STRDISP(sunbeam);
    //{printf("\n %s","sunbeam");}
    return 0;
}
*/


/*
#define SWAP(type,a,b) {type temp; temp=a; a=b; b=temp;}
int main(void)
{
    int n1=10;
    int n2=5;
    printf("Before Macro call : N1: %d N2 : %d",n1,n2);
    SWAP(int,n1,n2); //macro call 
    // {int temp; temp=n1; n1=n2; n2=temp;}
    printf("\n After Macro call : N1: %d N2 : %d",n1,n2);
    return 0;
}

*/


/*
#define SQR(a) a*a

int main(void)
{
    printf("%d",SQR(3+2));
              // 3+2*3+2 //11
    
    return 0;
}
*/

/*
#define SQR(a) a*a

int main(void)
{
    printf("%d",SQR(4));
    //printf("%d",a*a);
    //printf("%d",4*4);

    return 0;
}

*/


/*
#define PI 3.14 // Macro 
//PI is macro name 
//3.14 is macro definition

int main(void)
{
    printf("%f",PI); //macro call
        //wherever there is a macro call it gets expanded at that location
    return 0;
}

*/