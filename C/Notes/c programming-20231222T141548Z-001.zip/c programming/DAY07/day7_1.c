#include<stdio.h>
#include<stdlib.h>
#include<string.h>

// str[10] = akshita
//Find occurace of a 
// str[0]= a 100
//str[1] = k 101
//str[2] = s 102 .... '\0'
//char ch = a , count this
//count = 0

//while(str[i]!='\0')
//{
  //  if(str[i]==ch)
    //    count++;
//}
//print==> count ==> 2




//[a-z]
//[^a-z] = [A-Z]
//[^A-Z] = [a-z]
//[0-9]

/*
int main(void)
{
    char str[20];
    printf("Enter String:");
    scanf("%[A-Z]s",str);
    printf("String : %s",str);
    return 0;
}
*/


/*
int main(void)
{
    char str[20];
    printf("Enter String:");
    scanf("%[^.]s",str);
    printf("String : %s",str);
    return 0;
}
*/

/*
//scan set
int main(void)
{
    char str[20];
    printf("Enter String:");
    scanf("%[^\n]s",str); //read the string upto the first occurance of \n
    printf("String : %s",str);
    return 0;
}
*/




//strcpy(str1,str2); //copy the data from source to dest


//strcat  : Concatination  , join
//strcat(str1,str2)
// strcat("sun","beam") 
//"sunbeam"



/*
//strchr : it is used to find  a character within a string

int main(void)
{
    char str1[10];
    char *ptr=NULL;
    char ch;
    printf("Enter String :");
    scanf("%s",str1);
    printf("Enter character which you wish to search : ");
        // when the user will give input as "Enter " key from the keyboard
        //it will be considered as '\n' 
        //and it will be stored into &ch
    //if we wish to suppres the meaning of new line character
    scanf("%*c");
    scanf("%c",&ch);
    
    ptr=strchr(str1,ch);//search ch inside str1
    // yes : base address 
    // no : NULL
    if(ptr==NULL)
        printf("Character is not found");
    else
        printf("Character is found");
        
    return 0;
}

*/


/*
//strstr (find a substring within a string)

//str1: Sunbeam
//str2 : beam 
int main(void)
{
    char str1[10],str2[10];
    char *ptr=NULL;
    printf("Enter String :");
    scanf("%s",str1);
    printf("Enter substring which you wish to check : ");
    scanf("%s",str2);

    ptr=strstr(str1,str2);//search str2 inside str1
    // yes : base address 
    // no : NULL
    if(ptr==NULL)
        printf("String is not found");
    else
        printf("String is found");
        
    return 0;
}

*/


//strlen : length of the string

//char str[10]="Pune"; // 10
//char str[]="Pune"; // 5
//char *str="Pune"; //4bytes

/*
int main(void)
{
    char str[10];
    int len;
    printf("Enter String :");
    scanf("%s",str);
    len=strlen(str);
    printf("\n Length of entered string : %d",len);


    return 0;
}

*/