#include<stdio.h>
#include<stdlib.h>

/*
int main(int argc,char *argv[])
{
    int i;
    printf("Argument count : %d",argc);
    for(i=0;i<argc;i++)
    {
        printf("\n %s",argv[i]);
    }
    return 0;
}

*/