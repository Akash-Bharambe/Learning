#include<stdio.h>
#include<stdlib.h>

//#define ROW 3
//#define COL 3

// int a[ROW][COL];  // VALID
//int a[4][2] ; //valid
// int a[][3]={1,2,3,4,5,6,7,8,9,10};  //VALID
    // 1 2 3
    //4 5 6
    //7 8 9
    //10 0 0 


//int a[4][]={3,4,5,6,7,8,9,10}; //INVALID 
//int a[][]; // INVALID
    

/*


void accept_data(int a[3][3]);

int main(void)
{
    int a[3][3];
    accept_data(a);
    return 0;
}

void accept_data(int a[3][3])
{
       int i,j;
    printf("Enter elements:");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }

    printf("Array elements are:");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf(" %d ",a[i][j]);
        }
        printf("\n");
    }

}

*/


/*
int main(void)
{
    int a[3][3];
    int i,j;
    printf("Enter elements:");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }

    printf("Array elements are:");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf(" %d ",a[i][j]);
        }
    }

    return 0;
}

*/