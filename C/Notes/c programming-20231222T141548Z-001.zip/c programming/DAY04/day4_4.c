#include<stdio.h>
#include<stdlib.h>



/*
enum colors{RED,GREEN,BLUE};
int main(void)
{
    enum colors clr; //clr is a enum variable
    clr=RED;

    int var;
    //clr=GREEN;
    //clr =BLUE;
    printf("clr : %d",clr);
    printf("\n  %d ",sizeof(clr));

    var=GREEN+20;
    printf("\n VAR : %d",var);
    return 0;
}
*/


/*
enum options{EXIT,ADD,SUB,MUL,DIV,MOD};

int main(void)
{
    int num1,num2;
    enum options choice; //choice is a variable of type enum

    printf("Enter First Number :");
    scanf("%d",&num1);
    printf("\n Enter Second Number :");
    scanf("%d",&num2);
    do
    {
    printf("\n Enter Choice :0.EXIT 1.ADD 2.SUB 3.MUL 4. DIV 5.MOD ");
    scanf("%d",&choice);

    switch(choice)
    {
        case ADD: //case 1:
            printf("Addition : %d",num1+num2);
        break;

        case SUB: //case 2: 
        printf("\n subtraction  : %d",num1-num2);
       break;

       case MUL: //case 3: 
        printf("\n Multiplication  : %d",num1*num2);
        break;
        
        case DIV: 
        printf("\n Division : %d",num1/num2);
        break;
        
        case MOD: 
        printf("\n Mod : %d",num1%num2);
        break;       
    }
    }while(choice!=EXIT);

    return 0;
}

*/



/*

enum department{ADMIN,TRAINING,PLACEMENT};
int main(void)
{
    
    printf("%d",ADMIN); //ACCESSING THE ENUM ELEMENT DIRECTLY
    //to access the enum elements with the help of variables

    enum department e; //e is a variable of user defined datatype enum department
    e=TRAINING;
    printf("\n value inside e : %d",e);

    return 0;
}
*/

/*
enum department{admin=10,training,placement=50};
//deparment is name of enum 
//enum : enumerated list 
int main(void)
{
    printf("Admin value : %d",admin);
    printf("\n Training value : %d",training);
    printf("\n Placement value : %d",placement);

    return 0;
}
*/

/*
enum department{admin=10,training=20,placement=30};
//deparment is name of enum 
//enum : enumerated list 
int main(void)
{
    printf("Admin value : %d",admin);
    printf("\n Training value : %d",training);
    printf("\n Placement value : %d",placement);

    return 0;
}
*/


/*
enum department{admin,training,placement};
//deparment is name of enum 
//enum : enumerated list 
//admin,training,placecment all are elements within enum list
//admin : 0
//training : 1
//placment : 2 

int main(void)
{
    printf("Admin value : %d",admin);
    printf("\n Training value : %d",training);
    printf("\n Placement value : %d",placement);

    return 0;
}

*/

/*
int main(void)
{
    typedef int NUMBER;

    NUMBER num1,num2; //int num1,num2; 
    // int is real name
    //NUMBER is a nick name given to int

    int val1=50;
    num1=10;
    num2=5;
    printf("%d %d ",num1,num2); 
    printf("\n val1:%d ",val1);
    return 0;
}

*/