#include<stdio.h>
#include<stdlib.h>

// LOOP 
// for 
//while
//do while loop 


//nested for loop
int main(void)
{   
    int i,j;

    for(i=1;i<4;i++) // OUTER 
    {
        for(j=0;j<i;j++) // INNER 
        {
            printf(" * ");
        }
        printf("\n");

    }
    return 0;
}





/*
int main(void)
{
    int i=0;
    while(i<10)
    {
        printf(" %d ",i);
        i++;
    }
    return 0;
}

*/

/*
int main(void)
{
    int i;
    for(i=0;i<10;i++);
    printf("%d",i);
    return 0;
}

*/

/*
int main(void)
{
    int num=2;
    int i;

    // for(initialization ; conditional statment ; incr/decr)

    for(i=1 ;i<=10;i++) //i is loop variable
    {
        printf(" %d ",2*i);
    }

    //i=1 1<10 true printf(" %d ",2*i); printf("%d",2*1) 2   i++  i=2
    //i=2 2<10 true  printf(" %d ",2*i); printf("%d",2*2); 4  i++ i=3
    //i=3
    //i=4
    //i=5
    //i=6
    //i=7
    //i=8
    //i=9
    //i=10

    return 0;
}

*/