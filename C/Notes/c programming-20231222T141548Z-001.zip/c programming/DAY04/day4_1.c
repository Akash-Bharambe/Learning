#include<stdio.h>
#include<stdlib.h>

int main(void)
{
    int num1,num2;
    int choice;
    printf("Enter First Number :");
    scanf("%d",&num1);
    printf("\n Enter Second Number :");
    scanf("%d",&num2);
    printf("\n Enter Choice : 1.ADD 2.SUB 3.MUL 4. DIV 5.MOD ");
    scanf("%d",&choice);

    switch(choice)
    {
        case 1: 
            printf("Addition : %d",num1+num2);


        case 2: 
        printf("\n subtraction  : %d",num1-num2);
       break;

       case 3:
        printf("\n Multiplication  : %d",num1*num2);
        break;
        
        case 4: 
        printf("\n Division : %d",num1/num2);
        break;
        
        case 5: 
        printf("\n Mod : %d",num1%num2);
        break;       
    }

    return 0;
}







/*

//1.ADD 2.SUB 3.MUL 4. DIV 5.MOD
//switch case

int main(void)
{
    int num1,num2;
    int choice;
    printf("Enter First Number :");
    scanf("%d",&num1);
    printf("\n Enter Second Number :");
    scanf("%d",&num2);
    printf("\n Enter Choice : 1.ADD 2.SUB 3.MUL 4. DIV 5.MOD ");
    scanf("%d",&choice);

    switch(choice)
    {
       

//        case 1: //error: duplicate case value
  //          printf("inside case1");
    //    break;

        case 2: 
        printf("\n subtraction  : %d",num1-num2);
        break;

        case 2+1:  //case 3:
        printf("\n Multiplication  : %d",num1*num2);
        break;
        
        case 4: 
        printf("\n Division : %d",num1/num2);
        break;
        
        case 5: 
        printf("\n Mod : %d",num1%num2);
        break;

    //sequence of case does not matter
         case 1:
            printf("Addition : %d",num1+num2);
        break;

        default:
        printf("Invalid Option");
        break;
        
    }

    return 0;
}
*/


/*
int main(void)
{
     printf("%d",'\r');
     return 0;
}

*/



/*
//0 to 255
//-128 to 127


int main(void)
{
    int x=-1;
    printf("%d %d ",INT_MIN,INT_MAX);
    
    printf("\n %u,%x,%d",x>>1,x<<4,(unsigned)x>>1);
    //-2147483648 2147483647 
    return 0;
}
*/










