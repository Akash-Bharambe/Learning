#include<stdio.h>
#include<stdlib.h>


void sum(int n1,int n2);
//sum() is a user defined function and it is taking two arguements of type integer

int main(void)
{
    int a=30,b=20;
    sum(a,b); //function call // sum(30,20) //call by value concept
    //a,b are called as actual arguement
    sum(60,30);
    return 0;
}
void sum(int n1,int n2)  // n1: 30 n2: 20  //n1 n2 are formal arguments
{
    int res;
    res=n1+n2;
    printf("\n Addition : %d",res);

}




/*
//Functions
//1. Function declaration
//2. Function defintion / Function Body
//3. Function call 

//1. Function declaration
//<returntype> functionname();

//2. Function body
//<returntype> functionname() {.....}

//3. Function call
//by its name 


void disp();

//disp() is user defined function  and its return type is void
int main(void)
{
    disp(); //function call by its name 
    disp();
    return 0;
}

void disp()
{
    printf("\n Inside display function");
    printf("\n OC2 _ Topic: Function");
}

*/