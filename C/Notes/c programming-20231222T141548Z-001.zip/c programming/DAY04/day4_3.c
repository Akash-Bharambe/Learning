#include<stdio.h>
#include<stdlib.h>


/*
int main(void)
{
    int num=4;
    if(num==4)
        goto l1;
    printf("NUM : %d",num);
    l1:printf("number is equal to 4");
    return 0;
}
*/

/*
int main(void)
{
    int j;

    for(j=0;j<=7;j++)
    {
        if(j==4)
        {
            continue;
        }
    }
    printf("%d",j);
    return 0;
}
*/


/*
//goto keyword 
// goto labelname 
//labelname:statement
*/

/*
int main(void)
{
    int num1,num2;
    int choice;
    printf("Enter First Number :");
    scanf("%d",&num1);
    printf("\n Enter Second Number :");
    scanf("%d",&num2);
    do
    {
    printf("\n Enter Choice :0.EXIT 1.ADD 2.SUB 3.MUL 4. DIV 5.MOD ");
    scanf("%d",&choice);

    switch(choice)
    {
        case 1: 
            printf("Addition : %d",num1+num2);
        break;

        case 2: 
        printf("\n subtraction  : %d",num1-num2);
       break;

       case 3:
        printf("\n Multiplication  : %d",num1*num2);
        break;
        
        case 4: 
        printf("\n Division : %d",num1/num2);
        break;
        
        case 5: 
        printf("\n Mod : %d",num1%num2);
        break;       
    }
    }while(choice!=0);

    return 0;
}

*/