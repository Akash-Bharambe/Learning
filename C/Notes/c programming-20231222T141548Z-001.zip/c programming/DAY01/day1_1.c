//Documentation / Comments 
//1. Single line comment (//) 
//2. Multi line Comment(/* ..... * / )

//First Program to write "hello OC2 Batch"

/*
Author: Akshita
Org:Sunbeam Pune
Date:14th Decemeber 2020
*/

// File Inclusion area (Include header files)
#include<stdio.h> 
#include<stdlib.h>

int main() //entry point function
{
    printf("hello OC2 Batch"); //to display data on output screen we use printf() 
    return EXIT_SUCCESS; //return 0;
} //body of main / scope of main


//0 means numeric value 
// c Language numeric data : int as a datatype
//main function after successful execution it will return 0 (int)

//Editing the program
//Save the program
//Compiler (Compiles the code) (Covert High Level Lang Code into machine code)
 // gcc programname.c
// Execute the code 
 //  ./a.exe    OR   .\a.exe (WINDOWS)
 //  ./programname.exe 

 //UBUNTU (a.out)



