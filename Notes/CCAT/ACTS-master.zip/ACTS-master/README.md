# DAC ACTS PUNE
CDAC ACTS PUNE PG-DAC 2019 Assignment

## CDAC Journey 
#### Blog: https://cdacactspgdac.blogspot.com  
#### Youtube https://www.youtube.com/watch?v=NW1zEa1XKtU
#### Instagram www.instagram.com/vaibhavkurkute


## Update (2020)
<b>Learn to Code (Language & Framework) on Instagram Follow  www.instagram.com/awsdeveloper</b>


## CCEE Question Paper 2019 :
#### Access Here https://stoic-goldstine-f5b469.netlify.app/


## CDAC 2019 Schedule:
<ol>
      <li>Course Schedule: 19th Feb - 4th Aug, 2019</li>
      <li>Project Evaluation: 3rd Aug 2019 </li>
      <li>Placement Schedule: 6th Aug - October 2019 (With Ganesha Festival Holiday in September)</li>
      </ol>

<b> Feb 19' CCEE Question Paper is Available in CCEE Directory  (Module Wise)</b>

## Our Final Project:
      Code Plagiarism System : <b>https://github.com/PROJECTCDAC
      (Built with ReactJS and Spring Boot)

## [EXTRAS - FullStack Roadmap]
<b>Developer Technologies:</b>
<ul>
      <li>Full Stack Developer (V1) : Java : Angular/React/DoJo (FrontEnd) - Spring Boot/Hibernate/Kafka (Backend) - Git/Jenkins (DevOps)</li>
       <li>Full Stack Developer (V2) : JS : Angular/React/Dojo (FrontEnd) - NodeJS/ExpressJS (BackEnd) - Git/Jenkins (DevOps)</li>
      <li> Full Stack Developer (V3) : Python : Django/Flash (FrontEnd) - ElasticSearch/Redis -  Docker/Ansible (DevOps)</li>
</ul>
