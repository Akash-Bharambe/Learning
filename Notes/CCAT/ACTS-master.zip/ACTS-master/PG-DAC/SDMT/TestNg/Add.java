package com.app;


public class Add {

	public static int Addition(int a,int b,int c)	{
		return a+b+c;	
	}
}
