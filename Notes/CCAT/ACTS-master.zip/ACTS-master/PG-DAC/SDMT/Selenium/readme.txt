Installation:

1) Visit https://www.seleniumhq.org/download/
2) Download Selenium Driver for Java

3) Create Java Project in Eclipse
4) Right Click on Project -> Properties -> Java Build Path -> Libraries -> Add External Jar
5) Select all jars under libs also from Downloaded Zip
6) Apply 


Visit http://chromedriver.chromium.org/downloads
Download ChromeDrive Stable one (74.x version)

In Java Program  Set Path to this executable File

