exports.process=function(a,b){
	console.log(b.indexOf(a));
	return b.indexOf(a);
	
}
