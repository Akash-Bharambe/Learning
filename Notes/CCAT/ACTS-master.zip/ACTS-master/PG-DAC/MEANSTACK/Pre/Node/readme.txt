-> mkdir myapp
-> cd myapp
-> npm init
	(Edit Packages.json and add dependencies)
-> npm install 
	(To Install Dependencies)


----------------------- Ass 1. Started with Node Program

-> Create form.html
-> Create formProcess.js

	-> node formProcess.js 	
			1. Will start server at given port
			2. On / Get Method will return html file
			3. On Post Request from User will process.

	
----------------------- Ass 2. Started with ExpressJS
-> Create expressdiv.js
-> Create formdiv.js 
		(Function for Div)
-> Create formdiv.html
	-> copy this files in Node Application folder
		-> node expressdiv


------------------------ Ass 3.

	-> copy this files in Node Application folder
		-> node expressdiv
