Introduction:
	1) Has Features Supported by Browsers but not present in Javascript
		-Strong Typing (Easier to Debug)
		-Object Oriented (Class,Const,Access Modifiers,Generic)
		-Fix Errors at Compile Time
		-(Superset of JS)
		-Browser Do not Understand TS so compiled into JS (Transpile)
		
	2) Get Started:
		1) Create File: main.ts 
		2) Compile:		tsc main.ts
		3) Execute:		node main.ts
		4) Open:		code main.ts
- Type Annotations

- Arrow Functions

-Interfaces

-Classes

-Constructors

-Access Modifiers

-Properties

-Modules
