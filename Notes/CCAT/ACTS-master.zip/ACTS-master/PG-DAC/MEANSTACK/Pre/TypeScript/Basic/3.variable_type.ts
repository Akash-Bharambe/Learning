//Check Compiled main.js Code
    
    // let a: number; a:boolean; a: string; a: any; a: array[] = {1,2,3};
    
    let a;            //Type: any
    a = 1;
    a = true;
    a = 'a';



/*  Try Executing
  let count = 5;
  count = 'a';            //Error - Due to Strong Typing
*/
