

    const Red = 0;
    const Green = 1;
    enum Color {Red,Green};
    //enum Color {Red = 0,Green = 1};
    let bgcolor = Color.Green;
