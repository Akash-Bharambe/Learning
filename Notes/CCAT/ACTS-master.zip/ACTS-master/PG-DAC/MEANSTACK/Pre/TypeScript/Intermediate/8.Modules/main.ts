
    //Sample: import { Point } from '@angular/core';
    
    import { Point } from './point';
    //Multiple Import then separate by Comma

    let p = new Point(1,2);
    p.draw();
