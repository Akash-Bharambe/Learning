module_start = 08th April 2019
module_end =  15th April 2019

Teacher : Kaushal sharma


Workouts:
    1) Array
    2) Stack
        -Using Dynamic Array
        -Using LinkedList
    3) Queue
        -Using Dynamic Array
        -Using LinkedList       
    4) Circular Queue
    5) LinkedList
        1) Simple
        2) Doubly
        3) Circular
        4) Doubly Circular
    6) Tree
    
    7) Sorting Algorithm
           1) Bubble Sort
           2) Sequential Sort
           3) Insertion Sort
           4) Quick Sort
           5) Heap Sort
           6) Merge Sort
    8)  Search Algorithm
            1) Linear Search
            2) Binary Search
         
