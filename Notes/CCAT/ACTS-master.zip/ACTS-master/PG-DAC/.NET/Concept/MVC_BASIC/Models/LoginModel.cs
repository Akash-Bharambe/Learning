using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PahilaMVC.Models
{
    public class LoginModel
    {
        public string LoginID { get; }
        public string Password { get; }
        public string LoginType { get; }
    }
}
