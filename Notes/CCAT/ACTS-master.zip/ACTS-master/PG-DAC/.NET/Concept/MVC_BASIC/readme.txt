1) New Project
2) Project Template -> Web
3) Select MVC
      Untick Host on Cloud
      Change "Authentication" to No Authentication
(If Project has earlier Controller, Model, Views - Remove them)

4) Add New Controller (Name should be case sensitive)
5) Add New Model i.e CLASS
6) Add Views Under "Views/(Controller_Name)/"
7) Add Default View Template under "Views/Shared/"

8) Press Ctrl + F5 to Run Project
