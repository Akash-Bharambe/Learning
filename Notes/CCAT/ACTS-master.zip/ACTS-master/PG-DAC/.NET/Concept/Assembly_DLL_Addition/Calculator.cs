using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class Calculator
    {
        public void add(int a, int b)
        {
            Console.WriteLine(a + b);
        } 
    }
}
