package cust_exception;

@SuppressWarnings("serial")
public class EmpCustomException extends Exception {
	
	public EmpCustomException(String msg)
	{
		super(msg);
	}

}
