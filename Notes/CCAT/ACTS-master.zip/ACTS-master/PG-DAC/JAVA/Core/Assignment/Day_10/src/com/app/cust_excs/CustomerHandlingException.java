package com.app.cust_excs;

@SuppressWarnings("serial")
public class CustomerHandlingException extends Exception {
	public CustomerHandlingException(String msg)
	{
		super(msg);
	}
}
