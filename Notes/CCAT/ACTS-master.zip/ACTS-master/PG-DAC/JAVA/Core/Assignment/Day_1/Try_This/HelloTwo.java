//Try-This		//ERROR
/*	public class HelloThree
	{
		//Try-3		//WORKING
		public static void main(String[] args)
		{
			System.out.println("Hello World");
		}
	}	*/
	
//Try This
class A
{
	public static void main(String[] args)
		{
			System.out.println("Hello World");
		}
}
public class HelloTwo
{
	public static void main(String[] args)
		{
			System.out.println("Hello World");
		}
}
