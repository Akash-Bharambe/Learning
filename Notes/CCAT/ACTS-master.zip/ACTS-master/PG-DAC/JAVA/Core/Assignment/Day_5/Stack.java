package stack;

public interface Stack
{
	//public static final =- by implicity
	int SIZE = 10;
	//public abstract =- by implicity 
	void push(Emp e);
	Emp pop();
}
