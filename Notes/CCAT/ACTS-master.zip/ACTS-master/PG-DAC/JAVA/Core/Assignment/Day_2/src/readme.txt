//Command to be executed at this Directoy

  javac -d ../bin com/tester/TestStudent.java
  
  //Now Go to Bin Directory
