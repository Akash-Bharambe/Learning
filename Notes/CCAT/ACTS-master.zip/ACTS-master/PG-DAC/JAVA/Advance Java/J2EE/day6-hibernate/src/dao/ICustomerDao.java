package dao;

import pojos.Customer;

public interface ICustomerDao {
	String registerCustomer(Customer c);
}
