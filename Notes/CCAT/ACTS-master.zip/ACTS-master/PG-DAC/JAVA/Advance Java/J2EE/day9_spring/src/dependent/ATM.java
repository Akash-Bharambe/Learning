package dependent;

public interface ATM {
	void withdrawn(double amt);
	void deposit(double amt);
}
