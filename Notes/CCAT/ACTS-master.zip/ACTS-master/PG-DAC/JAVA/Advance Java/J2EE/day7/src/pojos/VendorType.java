package pojos;

public enum VendorType {
	ORACLE,SQL,MYSQL
}
