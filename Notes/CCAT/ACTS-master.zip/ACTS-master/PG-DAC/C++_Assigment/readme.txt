module_start : 20th Feb 2019
module_end : 8th Feb 2019 
module_exam : 8th Feb 2019

Question:

1) Create Employee Class with data members and pure virtual function CalSalary() to calculate salary of an employee for given days and inherit in another class Salary.

2) Create Menu Driven Program for Employee with File Handling to write and read data

3) Create Menu Driven Program for MobilePhone Store.

Teacher: Praphul Kolte
