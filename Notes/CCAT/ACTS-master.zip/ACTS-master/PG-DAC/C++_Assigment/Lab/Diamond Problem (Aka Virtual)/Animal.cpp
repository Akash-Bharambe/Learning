#include<iostream>
#include "Animal.h"
using namespace std;


void Animal::setWeight(int w)
{
		weight = w;
		cout << w;
}
void Tiger::setWidth(int w)
{
		width = w;
}
void Lion::setHeight(int h)
{
		height = h;	
}
