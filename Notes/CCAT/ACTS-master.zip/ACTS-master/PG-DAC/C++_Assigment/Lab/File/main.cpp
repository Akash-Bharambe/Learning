#include<iostream>
#include<fstream> 	//for File Operations
using namespace std;

int main()
{
	ofstream fout;		//write to file mode
	ifstream fin;		//read from file mode

	//int i;
	//cout<<"Enter Number";
	//cin>>i;

	//string c2,c1;
	//cout<<"Enter String1";
	//cin>>c1;
	//cin.get();		//Eater to eat extra space
	//cout<<"Enter String2";
	//cin>>c2;
	//cin.get();

	//fout.open("file.txt");		//By Default Write Mode, If no file present will create new
	//fout.open("file.txt",ios::out);
	//fout<<c1<<endl<<c2;
	
	//fout.close();


	//string c2;
	//fin.open("file.txt",ios::in);
	//fin>>c2;
	//cout<<c2;

	//fin.close();

	return 0;
}
