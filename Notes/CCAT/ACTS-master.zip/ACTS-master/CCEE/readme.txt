In case if you find any information wrong please comment there itself.

Tips for CCEE:
  Read Syllabus and Try to Read each and every Topic till Intermediate Level from Online Sources/Videos as per your convenience.
  Never read DUMPS. 
  You can read notes of different Institutes. 
  Remember they will not ask Questions on topic which is not in syllabus and its like 80% of Concepts on which Question is asked, you will feel like you have heard it somewhere (mostly in classroom).
  Go with Group Study Method and Remember important points.
  Try to Discuss/Tell what you learned with other student, (either you will get something more to hear about topic or it will help them to know the thing)
  Whatever Discussion happens Before 2 hrs of exam will be more helpful :-)

C++ : Questions on OOPS Concepts and Language Features
OS - Mostly questions on GPOS (General Purpose Operating System) core functionality
Java : Questions on OOPS Concepts and Language Features and Interface and Methods of Predifined Classes
J2EE :  Questions on Interface and Methods of Predifined Classes. Life Cycle
AWP : Question on Topics given in Syllabus and Mostly asked correct syntax
ASDM : Basic Question on Docker, UML, Software Engg Techniques and Cloud (Types of Infrastructure)
MEAN: Basic Question on Angular, TS, Project Folder Structure and CLI commands
DBMS: Basic Questions on No-SQL, Queries were not asked but what ketwords used for what is asked.
Dot.net :  Questions on OOPS Concepts and Language Features and WCF and WPF and Life Cycle
DS : Question Asked on Complexity, Code Snippet given we have to identify what it does, STL methods used on Generic DS



