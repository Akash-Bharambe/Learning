REF: https://github.com/vaibhavdes/ACTS/blob/master/Hack-Her-Rank/DS/2.2D_Array
