Useful for Interviews like AppDynamics
